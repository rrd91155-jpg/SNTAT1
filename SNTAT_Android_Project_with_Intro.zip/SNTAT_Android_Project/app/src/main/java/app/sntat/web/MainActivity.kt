package app.sntat.web

import android.app.Activity
import android.os.Bundle
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.VideoView
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.CookieManager
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private var splashView: VideoView? = null
    private val homeUrl = "https://sntat.app"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        root = FrameLayout(this)
        webView = WebView(this)
        root.addView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.setSupportMultipleWindows(false)
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = true

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()

        if (savedInstanceState != null) {
            val restored = webView.restoreState(savedInstanceState)
            if (restored == null) webView.loadUrl(homeUrl)
        } else {
            webView.loadUrl(homeUrl)
        }

        // The intro plays on every fresh app launch. Returning from Recents
        // keeps this Activity and WebView alive, so the intro does not replay.
        if (savedInstanceState == null) {
            playIntro()
        }
    }

    private fun playIntro() {
        val video = VideoView(this)
        splashView = video
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.splash}"))
        video.setOnCompletionListener { removeIntro() }
        video.setOnErrorListener { _, _, _ ->
            removeIntro()
            true
        }
        root.addView(video, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        video.start()
    }

    private fun removeIntro() {
        splashView?.let {
            it.stopPlayback()
            root.removeView(it)
        }
        splashView = null
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        splashView?.stopPlayback()
        if (this::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
